
<footer class="footer text-center">
        &copy;Copyrights - Proverbona Admin Panel
        <span class="text-right" style="font-size: 10pt; font-style: italic"> Last Updated: 30 May 2019 08:09PM  </span>

</footer>
</body>
</html>